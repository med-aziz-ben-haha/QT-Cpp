#include "gestion_profil_poste_departements.h"

#include <QApplication>
#include <QMessageBox>
#include "connexion.h"
#include <QtDebug>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Connexion c;
     bool t= c.ouvrirConnexion();
    Gestion_profil_poste_departements g;


    if (t)
    {

        qDebug()<<"hhhhhh"<<t;
        g.show();

    }else
        QMessageBox::critical(nullptr, QObject::tr("database is not open"),

       QObject::tr("Database could not initiate.\nConnection failed."), QMessageBox::Cancel);




    return a.exec();
}
