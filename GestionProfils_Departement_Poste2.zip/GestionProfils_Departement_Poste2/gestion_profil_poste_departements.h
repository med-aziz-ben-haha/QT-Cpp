#ifndef GESTION_PROFIL_POSTE_DEPARTEMENTS_H
#define GESTION_PROFIL_POSTE_DEPARTEMENTS_H
#include <QMainWindow>
#include "profil.h"
#include <QMainWindow>
#include "poste.h"
#include "departements.h"
namespace Ui {
class Gestion_profil_poste_departements;
}

class Gestion_profil_poste_departements : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gestion_profil_poste_departements(QWidget *parent = nullptr);
    ~Gestion_profil_poste_departements();

private slots:
    void on_pb_ajouter_clicked();

    void on_pb_supprimer_clicked();



    void on_pb_ajouter_3_clicked();

    void on_pb_supprimer_3_clicked();

    void on_pb_ajouter_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_chercher_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_lineEdit_cin_2_textChanged(const QString &arg1);

    void on_pb_ajouter_4_clicked();

    void on_pushButton_8_clicked();

    void on_pushButtonsuppposte_clicked();

    void on_pushButton_suppposte_clicked();

    void on_recherche_3_textChanged(const QString &arg1);

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_16_clicked();

    void on_recherche_3_textEdited(const QString &arg1);

    void on_recherche_4_textEdited(const QString &arg1);

    void on_recherche_4_textChanged(const QString &arg1);

    void on_pb_ajouter_5_clicked();

    void on_pushButton_9_clicked();

private:
    Ui::Gestion_profil_poste_departements *ui;
    profil tmpprofil,tableauu;
     poste tmpposte;
      departements tmpdepartements;

};
#endif // GESTION_PROFIL_POSTE_DEPARTEMENTS_H
