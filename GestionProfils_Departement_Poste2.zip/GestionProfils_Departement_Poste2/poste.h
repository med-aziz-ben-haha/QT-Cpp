#ifndef POSTE_H
#define POSTE_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QStringList>
#include <QtWidgets/QMainWindow>
QT_CHARTS_USE_NAMESPACE

class poste
{
public:
    poste();
    poste(int,int,QString);
    QString get_fonction();
    int get_idfonction();
    int get_salaire();
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int);
     bool supprimerposte(QString);
    QSqlQueryModel *affichetrie();
    QSqlQueryModel * recherche(const QString &idfonction);
    QSqlQueryModel * trier(const QString &critere,const QString &mode );
      QChartView * stat();
private:
    QString fonction;
    int idfonction,salaire;

};

#endif // POSTE_H
