#include "poste.h"
#include <QDebug>



poste::poste()
{
idfonction=0;
salaire=0;
fonction="";
}
poste::poste(int idfonction,int  salaire,QString fonction)
{
  this->idfonction=idfonction;
  this->salaire= salaire;
  this->fonction=fonction;
}


int poste::get_idfonction(){return idfonction;}
int  poste::get_salaire(){return salaire;}
QString poste::get_fonction(){return fonction;}
bool poste::ajouter()
{
QSqlQuery query;
QString res= QString::number(idfonction);
query.prepare("INSERT INTO poste (idfonction, salaire,fonction) "
                    "VALUES (:idfonction, :salaire, :fonction)");
query.bindValue(":idfonction", res);
query.bindValue(":salaire", salaire);
query.bindValue(":fonction",fonction);

return    query.exec();
}
QSqlQueryModel * poste::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from poste");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("idfonction"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("salaire "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("fonction"));
    return model;
}

bool poste::supprimer(int idfonctionn)
{
QSqlQuery query;
QString res= QString::number(idfonctionn);
query.prepare("Delete from poste where IDFONCTION= :idfonction ");
query.bindValue(":idfonction", res);
return    query.exec();
}
bool poste::supprimerposte(QString fonction)
{
    QString header ;
    QSqlQuery q;
    header = "Delete from poste where fonction =:fonction";
    q.prepare(header);
    q.bindValue(":fonction",fonction);
    return q.exec();
}
QSqlQueryModel * poste::affichetrie()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select idfonction,salaire,fonction from poste ORDER by salaire;");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("idfonction"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("salaire"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("fonction "));


    return model;
}
QSqlQueryModel * poste ::recherche (const QString &idfonction)
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("select * from poste where (IDFONCTION LIKE '"+idfonction+"%')");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDFONCTION"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("SALAIRE"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("FONCTION"));

    return model;
}
QSqlQueryModel *  poste::trier(const QString &critere,const QString &mode)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    //qDebug() <<mode;
    model->setQuery("select * from poste order by "+critere+" "+mode+"");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDFONCTION"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("SALAIRE"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("FONCTION"));

    return model;
}
QChartView * poste::stat(){

        QSqlQuery query;

        query.prepare("select  fonction,salaire from poste");

        query.exec();
        //int i=0;
        int j;
        //int nb[20];
     QList<QString> nomdp1;
        QString nom;
        QVector<QString> fonction;
        QVector<int>  price;

        while(query.next())
        {

            fonction.push_back(query.value(0).toString());
            price.push_back(query.value(1).toInt());
                  //i++;
        }



        QBarSet *set0 = new QBarSet("Altuve");

        for(j=0;j<price.length();j++)
        {
           *set0 << price.at(j) ;


        }

       //*set0 << nb[0] << nb[1] << nb[2] << nb[3] << nb[4] << nb[5]    ;


        QBarSeries *series = new QBarSeries();


        series->append(set0);


        QChart *chart = new QChart();

        // Add the chart
        chart->addSeries(series);

        // Set title
        chart->setTitle("Salaire per fonction");


        chart->setAnimationOptions(QChart::AllAnimations);


        QStringList categories;
      // categories <<  nomdp1.at(0) <<  nomdp1.at(1) << nomdp1.at(2) << nomdp1.at(3) << nomdp1.at(4) <<  nomdp1.at(5)  ;
       for(j=0;j<fonction.length();j++)
       {
          categories << fonction.at(j) ;


       }


        QBarCategoryAxis *axis = new QBarCategoryAxis();
        axis->append(categories);
        chart->createDefaultAxes();
        // 1. Bar chart
               chart->setAxisX(axis, series);




        // Define where the legend is displayed
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);

        // Used to display the chart
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);


        return  chartView;
}

