#include "profil.h"
#include <QDebug>
#include <QDate>
profil::profil()
{
 iddepartement=0;
idfonction=0;
idprofil=0;
competences="";
naturediplomeobtenu="";
anneeexperience=0;
}
profil::profil(int iddepartement,int  idfonction,int idprofil,QString competences,QString naturediplomeobtenu,int anneeexperience,QDate ldate)
{
   this->iddepartement=iddepartement;
  this->idfonction=idfonction;
  this->idprofil = idprofil;
  this->competences=competences;
    this->naturediplomeobtenu= naturediplomeobtenu;
    this->anneeexperience=anneeexperience;
    this->ldate=ldate;
}


int profil::get_iddepartement(){return iddepartement;}
int  profil::get_idfonction(){return idfonction;}
int  profil::get_idprofil(){return idprofil;}
QString profil::get_competences(){return competences;}
QString profil::get_naturediplomeobtenu(){return naturediplomeobtenu;}
int profil::get_anneeexperience(){return  anneeexperience;}
QDate profil::get_ldate(){return ldate;}
bool profil::ajouter()
{
QSqlQuery query;

query.prepare("INSERT INTO profil (iddepartement, idfonction,idprofil,competences,naturediplomeobtenu,anneeexperience,ldate) "
                    "VALUES (:iddepartement, :idfonction, :idprofil, :competences, :naturediplomeobtenu, :anneeexperience, :ldate)");
query.bindValue(":iddepartement", iddepartement);
query.bindValue(":idfonction",idfonction);
query.bindValue(":idprofil",idprofil);
query.bindValue(":competences",competences);
query.bindValue(":naturediplomeobtenu",naturediplomeobtenu);
query.bindValue(":anneeexperience",anneeexperience);
query.bindValue(":ldate",ldate);
return    query.exec();
}
bool profil::modifier(int iddepartement)
{
    QSqlQuery query;
    QString res= QString::number(iddepartement);
    query.prepare("Update  profil set  IDDEPARTEMENT=:iddepartement,IDFONCTION=:idfonction,IDPROFIL=:idprofil,COMPETENCES=:competences,NATUREDIPLOMEOBTENU=:naturediplomeobtenu,ANNEEEXPERIENCE=:anneexperience where IDDEPARTEMENT =:iddepartement");
    query.bindValue(":iddepartement",res);
    query.bindValue(":idfonction",idfonction);
    query.bindValue(":idprofil",idprofil);
    query.bindValue(":competences",competences);
    query.bindValue(":naturediplomeobtenu",naturediplomeobtenu);
    query.bindValue(":anneeexperience",anneeexperience);
     query.bindValue(":ldate",ldate);

    return  query.exec();

}
QSqlQueryModel * profil::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from profil");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("iddepartement"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("idfonction "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("idprofil"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("competences"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("naturediplomeobtenu"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("anneeexperience"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("ldate"));
    return model;
}

bool profil::supprimer(int idprofill)
{
QSqlQuery query;
QString res= QString::number(idprofill);
query.prepare("Delete from profil where IDPROFIL = :idprofil ");
query.bindValue(":idprofil", res);
return    query.exec();
}




QSqlQueryModel * profil ::recherche (const QString &iddepartement)
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("select * from profil where (iddepartement LIKE '"+iddepartement+"%')");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDDEPARTEMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("IDFONCTION"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("IDPROFIL"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("COMPETENCES"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("NATUREDIPLOMEOBTENU"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ANNEEEXPERIENCE"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("LDATE"));


    return model;
}





QSqlQueryModel * profil::affichetrie()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select iddepartement,idfonction,idprofil,competences,naturediplomeobtenu,anneeexperience from profil ORDER by idfonction ;");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("iddepartement"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("idfonction"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("idprofil "));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("competences"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("naturediplomeobtenu"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("anneeexperience"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("ldate"));
    return model;
}
