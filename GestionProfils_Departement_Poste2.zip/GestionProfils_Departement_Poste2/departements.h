#ifndef DEPARTEMENTS_H
#define DEPARTEMENTS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QStringList>
#include <QtWidgets/QMainWindow>
QT_CHARTS_USE_NAMESPACE
class departements
{
public:
    departements();
    departements(int,QString,int,int);
    int get_nombredeplace();
    QString get_depactuel();
    int get_iddepartement();
    int get_nbemploye();
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    bool modifier(int);
    QSqlQueryModel * recherche(const QString &nombredeplace);
    QSqlQueryModel * trier(const QString &critere,const QString &mode );
    QChartView * stat();
private:
    QString depactuel;

    int iddepartement,nbemploye,nombredeplace;

};

#endif // DEPARTEMENTS_H

