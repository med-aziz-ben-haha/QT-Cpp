#include "departements.h"
#include <QDebug>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QStringList>
#include <QtWidgets/QMainWindow>
QT_CHARTS_USE_NAMESPACE
departements::departements()
{
iddepartement=0;
depactuel="";
nombredeplace=0;
nbemploye=0;
}
departements::departements(int iddepartement,QString depactuel,int nombredeplace,int nbemploye)
{
  this->iddepartement=iddepartement;
  this->depactuel=depactuel;
  this->nombredeplace=nombredeplace;
    this->nbemploye=nbemploye;
}
QString departements::get_depactuel(){return  depactuel;}
int departements::get_nombredeplace(){return nombredeplace;}
int departements::get_iddepartement(){return  iddepartement;}
int departements::get_nbemploye(){return  nbemploye;}

bool departements::ajouter()
{
QSqlQuery query;
QString res= QString::number(iddepartement);
query.prepare("INSERT INTO departements (IDDEPARTEMENT, depactuel, nombredeplace,nbemploye) "
                    "VALUES (:iddepartement, :depactuel, :nombredeplace, :nbemploye)");
query.bindValue(":iddepartement", res);
query.bindValue(":depactuel", depactuel);
query.bindValue(":nombredeplace",nombredeplace);
query.bindValue(":nbemploye",nbemploye);
return    query.exec();
}
bool departements::modifier(int iddepartement)
{
    QSqlQuery query;
    QString res= QString::number(iddepartement);
    query.prepare("Update  departements set  IDDEPARTEMENT=:iddepartement,DEPACTUEL=:depactuel,NOMBREDEPLACE=:nombredeplace,NBEMPLOYE=:nbemploye where IDDEPARTEMENT =:iddepartement ");
    query.bindValue(":iddepartement",res);
    query.bindValue(":depactuel",depactuel);
    query.bindValue(":nombredeplace",nombredeplace);
    query.bindValue(":nbemploye",nbemploye);

    return  query.exec();
}
QSqlQueryModel * departements::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from departements");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDDEPARTEMENT"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("depactuel "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("nombredeplace"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("nbemploye"));
    return model;
}

bool departements::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from departements where IDDEPARTEMENT = :iddepartement ");
query.bindValue(":iddepartement", res);
return    query.exec();
}
QSqlQueryModel * departements ::recherche (const QString &nombredeplace)
{
    QSqlQueryModel * model = new QSqlQueryModel();
    model->setQuery("select * from departements where (NOMBREDEPLACE LIKE '"+nombredeplace+"%')");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDDEPARTEMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DEPACTUEL"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOMBREDEPLACE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("NBEMPLOYE"));

    return model;
}
QSqlQueryModel *  departements::trier(const QString &critere,const QString &mode)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    //qDebug() <<mode;
    model->setQuery("select * from departements order by "+critere+" "+mode+"");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDDEPARTEMENT"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("DEPACTUEL"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOMBREDEPLACE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("NBEMPLOYE"));
    return model;
}
/*QChartView * departements::stat(){

        QSqlQuery query;

        query.prepare("select  depactuel,nbemploye from departements");

        query.exec();
        int i=0;

        int nb[20];
      QList<QString> nomdp1;
        QString nom;



        while(query.next())
        {
        nb[i]=query.value(1).toInt();
        nom=query.value(0).toString();
         nomdp1<<nom;
        qDebug()<<i;
        qDebug()<<nb[i];
        //qDebug()<<nomdp1.at(i);
                  i++;
        }



        QBarSet *set0 = new QBarSet("Altuve");



        *set0 << nb[0] << nb[1] << nb[2] << nb[3] << nb[4] <<nb[5]    ;


        QBarSeries *series = new QBarSeries();


        series->append(set0);


        QChart *chart = new QChart();

        // Add the chart
        chart->addSeries(series);

        // Set title
        chart->setTitle("Number of employees in department");


        chart->setAnimationOptions(QChart::AllAnimations);


        QStringList categories;
       //categories <<  nomdp1.at(0) <<  nomdp1.at(1) << nomdp1.at(2) << nomdp1.at(3) << nomdp1.at(4) <<  nomdp1.at(5) << nomdp1.at(6) ;


        QBarCategoryAxis *axis = new QBarCategoryAxis();
        axis->append(categories);
        chart->createDefaultAxes();
        // 1. Bar chart
               chart->setAxisX(axis, series);




        // Define where the legend is displayed
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);

        // Used to display the chart
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);


        return  chartView;
}*/
QChartView * departements::stat(){

        QSqlQuery query;

        query.prepare("select  depactuel,nbemploye from departements");

        query.exec();
        //int i=0;
        int j;
        //int nb[20];
      QList<QString> nomdp1;
        QString nom;
        QVector<QString> nomdepartement;
        QVector<int> nombremploye ;

        while(query.next())
        {
        /*nb[i]=query.value(1).toInt();
        nom=query.value(0).toString();
         nomdp1<<nom;
        qDebug()<<i;
        qDebug()<<nb[i];
        //qDebug()<<nomdp1.at(i);*/
            nomdepartement.push_back(query.value(0).toString());
            nombremploye.push_back(query.value(1).toInt());
                  //i++;
        }



        QBarSet *set0 = new QBarSet("Altuve");

        for(j=0;j<nombremploye.length();j++)
        {
           *set0 << nombremploye.at(j) ;


        }

       //*set0 << nb[0] << nb[1] << nb[2] << nb[3] << nb[4] << nb[5]    ;


        QBarSeries *series = new QBarSeries();


        series->append(set0);


        QChart *chart = new QChart();

        // Add the chart
        chart->addSeries(series);

        // Set title
        chart->setTitle("Number of employees per department");


        chart->setAnimationOptions(QChart::AllAnimations);


        QStringList categories;
      // categories <<  nomdp1.at(0) <<  nomdp1.at(1) << nomdp1.at(2) << nomdp1.at(3) << nomdp1.at(4) <<  nomdp1.at(5)  ;
       for(j=0;j<nomdepartement.length();j++)
       {
          categories << nomdepartement.at(j) ;


       }


        QBarCategoryAxis *axis = new QBarCategoryAxis();
        axis->append(categories);
        chart->createDefaultAxes();
        // 1. Bar chart
               chart->setAxisX(axis, series);




        // Define where the legend is displayed
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);

        // Used to display the chart
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);


        return  chartView;
}
