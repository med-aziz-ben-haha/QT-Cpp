#include "connexion.h"
#include <exception>
#include <QtDebug>
Connexion::Connexion()
{}

bool Connexion::ouvrirConnexion()
{bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("testbd");
db.setUserName("salem");//inserer nom de l'utilisateur
db.setPassword("98375694");//inserer mot de passe de cet utilisateur
if (db.open())
{
    test=true;
qDebug()<<"salut damdoum";
}
else
    throw QString ("Erreur Paramétres");
return  test;
}
void Connexion::fermerConnexion()
{db.close();}
