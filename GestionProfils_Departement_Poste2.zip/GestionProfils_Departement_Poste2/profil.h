#ifndef PROFIL_H
#define PROFIL_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>
class profil
{
public:
    profil();
    profil(int,int,int,QString,QString,int,QDate);
    QString get_competences();
    int get_idfonction();
    int get_idprofil();
    int get_anneeexperience();
    int get_iddepartement();
     QDate get_ldate();
    QString get_naturediplomeobtenu();
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(int);
        bool modifier(int);
        QSqlQueryModel *affichetrie();
        QSqlQueryModel * recherche(const QString &iddepartement);
private:
    QString competences,naturediplomeobtenu;
    int idfonction,idprofil,iddepartement,anneeexperience;
    QDate ldate;

};

#endif // PROFIL_H

