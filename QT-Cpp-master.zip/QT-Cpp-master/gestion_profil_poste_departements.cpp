

#include "gestion_profil_poste_departements.h"
#include "ui_gestion_profil_poste_departements.h"
#include "profil.h"
#include "poste.h"
#include "departements.h"
#include <QMessageBox>
#include <QTextStream>
#include <QApplication>
#include <QTextEdit>
#include <QPainter>
#include <QtPrintSupport/QPrinter>
#include <QTextDocument>
/*#include <QPrintDialog>*/
#include<QDate>

#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

QT_CHARTS_USE_NAMESPACE
Gestion_profil_poste_departements::Gestion_profil_poste_departements(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gestion_profil_poste_departements)
{

ui->setupUi(this);
ui->tabprofil->setModel(tmpprofil.afficher());
ui->tableposte->setModel(tmpposte.afficher());
ui->tabdepartements->setModel(tmpdepartements.afficher());
ui->verticalLayout->addWidget(tmpdepartements.stat());
ui->verticalLayout_2->addWidget(tmpposte.stat());
}






Gestion_profil_poste_departements::~Gestion_profil_poste_departements()
{
    delete ui;
}

void Gestion_profil_poste_departements::on_pb_ajouter_clicked()
{
 int reponse=QMessageBox::question(this,"Confirmation","Voulez vous ajouter ce profil?", QMessageBox::Yes | QMessageBox::No);
 if (reponse == QMessageBox::Yes)
    {
    int iddepartement = ui->lineEdit_cin->text().toInt();
    int idfonction = ui->lineEdit_idfonction->text().toInt();
    int idprofil = ui->lineEdit_id->text().toInt();
    QDate ldate=ui->dateTimeEdit->date();
   QString competences=ui->comboBox_2->currentText();
    QString naturediplomeobtenu= ui->lineEdit_nometprenom_3->text();
    int anneeexperience= ui->lineEdit_nometprenom_4->text().toInt();
    int avecemploye;
    if (ui->Avecprofil->isChecked())
    {
        avecemploye=1;
    }
    else
    {
        avecemploye=0;
    }
 profil p(iddepartement,idfonction,idprofil,competences,naturediplomeobtenu,anneeexperience,ldate);
  bool test=p.ajouter();
  if(test)
{ui->tabprofil->setModel(tmpprofil.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un profil"),
                  QObject::tr("Profil ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else{
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un profil"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
  }
 }
 else if (reponse == QMessageBox::No)
    {
         QMessageBox::critical(this, "Annulation", "L'ajout de ce profil a ete annuler !");
    }


}








void Gestion_profil_poste_departements::on_pb_supprimer_clicked()
{
    int idprofil = ui->lineEdit_id_2->text().toInt();
    bool test=tmpprofil.supprimer(idprofil);
    if(test)
    {ui->tabprofil->setModel(tmpprofil.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un profil"),
                    QObject::tr("Profil supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un profil"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}


void Gestion_profil_poste_departements::on_pb_ajouter_2_clicked()
{

        {
            int iddepartement= ui->lineEdit_5->text().toInt();

            int idfonction= ui->lineEdit_6->text().toInt();
            int idprofil= ui->lineEdit_7->text().toInt();
            QDate ldate=ui->dateTimeEdit_3->date();
            QString competences= ui->comboBox_5->currentText();

            QString naturediplomeobtenu= ui->lineEdit_15->text();
            int anneeexperience= ui->lineEdit_16->text().toInt();



         profil p(iddepartement,idfonction,idprofil,competences,naturediplomeobtenu,anneeexperience,ldate);

          if(p.modifier(iddepartement))
          {
              QMessageBox::information(nullptr, QObject::tr("Modifier un profil"),
                          QObject::tr("profil modifieé.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);

          }
          else
          {
              QMessageBox::critical(nullptr, QObject::tr("Modifier un profil "),
                                    QObject::tr("Erreur !.\n"
                                                "Click Cancel to exit."), QMessageBox::Cancel);
          }
        }

}

void Gestion_profil_poste_departements::on_pushButton_clicked()
{
    {
        {
        profil F;
        ui->tableaau->setModel(F.affichetrie());
        }
    }
}


void Gestion_profil_poste_departements::on_pushButton_chercher_clicked()

{
    {
        int iddepartement = ui->lineEdit_cin_2->text().toInt();
        QSqlQuery query;
        QString res= QString::number(iddepartement);
        query.prepare("Select *from profil where IDDEPARTEMENT = :iddepartement");
        query.bindValue(":iddepartement",iddepartement);

        if(query.exec())
        {
            QMessageBox::information(nullptr, QObject::tr("Chercher un profil"),
                        QObject::tr("trouvée.Vous pouvez modifier le profil !\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

            while(query.next())
            {
                 /*ui->lineEdit_cin_2->setText(query.value(1).toString());*/
                 ui->lineEdit_idfonction_2->setText(query.value(1).toString());
                 ui->lineEdit_idprofil_2->setText(query.value(2).toString());

                 ui->lineEdit_nometprenom_2->setText(query.value(3).toString());
                  ui->lineEdit_13->setText(query.value(4).toString());
                    ui->lineEdit_14->setText(query.value(5).toString());




            }

        }
        else
        {
            QMessageBox::critical(nullptr, QObject::tr("Rechercher un profil"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
    }
}




void Gestion_profil_poste_departements::on_pushButton_2_clicked()

    {
    int idfonction = ui->lineEdit_idfonction_4->text().toInt();
    bool test=tmpposte.supprimer(idfonction);
    if(test)
    {ui->tableposte->setModel(tmpposte.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un poste"),
                    QObject::tr("poste supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un poste"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


    }


void Gestion_profil_poste_departements::on_pushButton_3_clicked()
{
    {
        {
       poste p;
        ui->tableView->setModel(p.affichetrie());
        }
    }
}

void Gestion_profil_poste_departements::on_pushButton_4_clicked()
{
    int reponse=QMessageBox::question(this,"Confirmation","Voulez vous ajouter ce poste?", QMessageBox::Yes | QMessageBox::No);
    if (reponse == QMessageBox::Yes)
    {
    int iddepartement = ui->lineEdit_identifiant->text().toInt();
    int nombredeplace= ui->lineEdit_anciendep->text().toInt();
    QString depactuel= ui->lineEdit_depactuel->text();
    int nbemploye= ui->lineEdit_nbemploye->text().toInt();
    int avecdepartmement;
   if (ui->Avecdepartement->isChecked())
   {
       avecdepartmement=1;
   }
   else
   {
       avecdepartmement=0;
   }
  departements d(iddepartement,depactuel,nombredeplace,nbemploye);
  bool test=d.ajouter();
  if(test)
{ui->tabdepartements->setModel(tmpdepartements.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un départements"),
                  QObject::tr("Départements ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else{
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un departements"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
    }
  }
  else if (reponse == QMessageBox::No)
     {
          QMessageBox::critical(this, "Annulation", "L'ajout de ce profil a ete annuler !");
     }





}


void Gestion_profil_poste_departements ::on_pushButton_5_clicked()
{
int iddepartement= ui->lineEdit_identifiant_2->text().toInt();
bool test=tmpdepartements.supprimer(iddepartement);
if(test)
{ui->tabdepartements->setModel(tmpdepartements.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Supprimer un departements"),
                QObject::tr("Departement supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un departement"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}


void Gestion_profil_poste_departements::on_pushButton_6_clicked()
{
    {
                    int iddepartement= ui->lineEdit->text().toInt();
                  QString depactuel= ui->lineEdit_2->text();
                    int nombredeplace= ui->lineEdit_3->text().toInt();



                     int nbemploye= ui->lineEdit_4->text().toInt();


                 departements d(iddepartement,depactuel,nombredeplace,nbemploye);

                  if(d.modifier(iddepartement))
                  {
                      QMessageBox::information(nullptr, QObject::tr("Modifier un departement"),
                                  QObject::tr("departement modifieé.\n"
                                              "Click Cancel to exit."), QMessageBox::Cancel);

                  }
                  else
                  {
                      QMessageBox::critical(nullptr, QObject::tr("Modifier un departement "),
                                            QObject::tr("Erreur !.\n"
                                                        "Click Cancel to exit."), QMessageBox::Cancel);
                  }
                }
}

void Gestion_profil_poste_departements::on_pushButton_7_clicked()
{
    {
            int iddepartement= ui->lineEdit_9->text().toInt();
            QSqlQuery query;
            QString res= QString::number(iddepartement);
            query.prepare("Select *from departements where IDDEPARTEMENT = :iddepartement");
            query.bindValue(":iddepartement",iddepartement);

            if(query.exec())
            {
                QMessageBox::information(nullptr, QObject::tr("Chercher un departement"),
                            QObject::tr("trouvée.Vous pouvez modifier le departement !\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

                while(query.next())
                {
                     /*ui->lineEdit_cin_2->setText(query.value(1).toString());*/
                     ui->lineEdit_10->setText(query.value(1).toString());
                     ui->lineEdit_11->setText(query.value(2).toString());

                     ui->lineEdit_12->setText(query.value(3).toString());


                }

            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Rechercher un departement"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

            }
        }
}

/*void MainWindow::on_lineEdit_cin_2_textChanged(const QString &arg1)
{

        ui->tabdepartements->setModel(tmpdepartements.recherche(arg1));

}*/




void Gestion_profil_poste_departements::on_lineEdit_cin_2_textChanged(const QString &arg1)
{

     ui->tabprofil->setModel(tmpprofil.recherche(arg1));

}



void Gestion_profil_poste_departements::on_recherche_3_textChanged(const QString &arg1)
{
    ui->tabposte->setModel(tmpposte.recherche(arg1));
}

void Gestion_profil_poste_departements::on_pushButton_14_clicked()
{


        ui->tabposte->setModel(tmpposte.afficher());

}



/*void MainWindow::on_pushButton_8_clicked()
{
    QString strStream;
                QTextStream out(&strStream);
                const int rowCount = ui->tabposte->model()->rowCount();
                const int columnCount =ui->tabposte->model()->columnCount();

                out <<  "<html>\n"
                        "<head>\n"
                        "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                        <<  QString("<title>%1</title>\n").arg("eleve")
                        <<  "</head>\n"
                        "<body bgcolor=#CFC4E1 link=#5000A0>\n"
                            "<h1>Liste des POSTES</h1>"

                            "<table border=1 cellspacing=0 cellpadding=2>\n";

                // headers
                    out << "<thead><tr bgcolor=#f0f0f0>";
                    for (int column = 0; column < columnCount; column++)
                        if (!ui->tabposte->isColumnHidden(column))
                            out << QString("<th>%1</th>").arg(ui->tabposte->model()->headerData(column, Qt::Horizontal).toString());
                    out << "</tr></thead>\n";
                    // data table
                       for (int row = 0; row < rowCount; row++) {
                           out << "<tr>";
                           for (int column = 0; column < columnCount; column++) {
                               if (!ui->tabposte->isColumnHidden(column)) {
                                   QString data = ui->tabposte->model()->data(ui->tabposte->model()->index(row, column)).toString().simplified();
                                   out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                               }
                           }
                           out << "</tr>\n";
                       }
                       out <<  "</table>\n"
                           "</body>\n"
                           "</html>\n";

        QTextDocument *document = new QTextDocument();
        document->setHtml(strStream);


        //QTextDocument document;
        //document.setHtml(html);
        QPrinter printer(QPrinter::PrinterResolution);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName("poste.pdf");
        document->print(&printer);
}*/

void Gestion_profil_poste_departements::on_pushButton_15_clicked()
{
    QString mode;
        if (ui->checkBox_6->isChecked())
        {
            mode="DESC";
        }
        else
        {
            mode="ASC";
        }
        ui->tabposte->setModel(tmpposte.trier(ui->comboBox->currentText(),mode));
}



void Gestion_profil_poste_departements::on_pushButton_17_clicked()
{
      ui->tabdepartement_2->setModel(tmpdepartements.afficher());
}

void Gestion_profil_poste_departements::on_pushButton_16_clicked()
{
    QString mode;
        if (ui->checkBox_7->isChecked())
        {
            mode="DESC";
        }
        else
        {
            mode="ASC";
        }
        ui->tabdepartement_2->setModel(tmpdepartements.trier(ui->comboBox_3->currentText(),mode));
}

void Gestion_profil_poste_departements::on_recherche_4_textChanged(const QString &arg1)
{
     ui->tabdepartement_2->setModel(tmpdepartements.recherche(arg1));
}




void Gestion_profil_poste_departements::on_pb_ajouter_5_clicked()
{
    int idfonction = ui->lineEdit_idfonction_3->text().toInt();
    int salaire= ui->lineEdit_salaire->text().toInt();
    QString fonction= ui->comboBox_4->currentText();

        int j;

       bool test2=true;

       bool test4=false;

       for (j=0;j<fonction .length();j++) {
           if (fonction [j]=="0" || fonction [j]=="1" || fonction [j]=="2" || fonction [j]=="3" || fonction [j]=="4" || fonction [j]=="5" || fonction [j]=="6" || fonction [j]=="7" || fonction [j]=="8" || fonction [j]=="9")
              {
               test2=false;
               }
       }

       if (ui->lineEdit_salaire->text().length()>=3)
       {
           test4=true;
       }else{
       }
            if ( test2  && test4)
                {
      poste p(idfonction,salaire,fonction);
      bool test=p.ajouter();
      if(test)
    {

          ui->tableposte->setModel(tmpposte.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("Ajouter un Poste"),
                      QObject::tr("Departement ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);

    }
      else
          QMessageBox::critical(nullptr, QObject::tr("Ajouter un Poste"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);


    }

            else if (test2==false)
                QMessageBox::critical(nullptr, QObject::tr("Ajouter un Poste"),
                            QObject::tr("Erreur ! pas de chiffres dans la fonction \n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

            else if (test4==false)
                QMessageBox::critical(nullptr, QObject::tr("Ajouter un Poste"),
                            QObject::tr("Erreur ! Salaire incorrect. Il faut plus que 3 chiffres \n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
}

void Gestion_profil_poste_departements::on_pushButton_9_clicked()
{
      ui->tabdepartement_2->setModel(tmpdepartements.afficher());
}
