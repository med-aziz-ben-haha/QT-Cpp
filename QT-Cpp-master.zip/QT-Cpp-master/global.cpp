#include "global.h"
#include <QString>

// ALL THE GLOBAL DEFINITIONS

QString tmp = "hello";
QString sel_emp = "sel emp";
QString sel_cong = "sel cong";
QString sel_cong_rh = "sel cong rh";
QString name = "Admin";
qreal count=1;
qreal login_times=0;



